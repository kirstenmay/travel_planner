from django.shortcuts import render, redirect
from django.contrib import messages
from .models import *
import bcrypt
import datetime


def login_reg(request):
    return render(request, 'login_reg/register.html')

def register(request):
    errors = User.objects.reg_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value, extra_tags=key)
        return redirect('/')
    else:
        password = request.POST['password']
        pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
        new_user = User.objects.create(first_name = request.POST['first_name'], last_name = request.POST['last_name'], birthday = request.POST['birthday'], email = request.POST['email'], password = pw_hash)
        request.session['userid'] = new_user.id
        username = new_user.first_name
        request.session['username'] = username
        return redirect("/dashboard")

def login(request):
    errors = User.objects.login_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value, extra_tags=key)
        return redirect("/")
    else:
        user = User.objects.filter(email = request.POST['login_email'])
        logged_user = user[0]
        request.session['userid'] = logged_user.id
        username = logged_user.first_name
        request.session['username'] = username
        return redirect('/dashboard')
        

def dashboard(request):
    if 'userid' in request.session:
        context = {
            'user_trips': Trip.objects.filter(user = request.session['userid']),
            'other_trips': Trip.objects.exclude(user = request.session['userid'])
        }
        return render(request, 'login_reg/dashboard.html', context)
    else: 
        return redirect("/")

def join_trip(request, trip_id):
    if 'userid' in request.session:
        user = User.objects.get(id = int(request.session['userid']))
        trip = Trip.objects.get(id = trip_id)
        trip.user.add(user)
        return redirect("/dashboard")
    else: 
        return redirect("/")

def leave_trip(request, trip_id):
    if 'userid' in request.session:
        user = User.objects.get(id = int(request.session['userid']))
        trip = Trip.objects.get(id = trip_id)
        trip.user.remove(user)
        return redirect('/dashboard')
    else:
        return redirect('/')

def add_trip(request):
    if 'userid' in request.session:
        return render(request, 'login_reg/add_trip.html')
    else: 
        return redirect("/")

def new_trip(request):
    if 'userid' in request.session:
        errors = Trip.objects.new_trip_val(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value, extra_tags=key)
            return redirect("/add_trip")
        user = User.objects.get(id = request.session['userid'])
        trip = Trip.objects.create(destination = request.POST['destination'], start_date = request.POST['start_date'], end_date = request.POST['end_date'], plan = request.POST['plan'], creator = user)
        trip.user.add(user)
        return redirect("/dashboard")
    else: 
        return redirect("/")

def edit_trip(request, trip_id):
    if 'userid' in request.session:
        context = {
            'trip': Trip.objects.get(id=trip_id)
        }
        return render(request, 'login_reg/edit_trip.html', context)
    else: 
        return redirect("/")

def change_trip(request):
    if 'userid' in request.session:
        trip = Trip.objects.get(id = int(request.POST['trip']))
        user = Trip.objects.get(id = trip.id).user.first()
        if int(request.session['userid']) == user.id:
            errors = Trip.objects.edit_trip_val(request.POST)
            if len(errors) > 0:
                for key, value in errors.items():
                    messages.error(request, value, extra_tags=key)
                return redirect(f"/edit_trip/{trip.id}")
            trip.destination = request.POST['destination']
            trip.start_date = request.POST['start_date']
            trip.end_date = request.POST['end_date']
            trip.plan = request.POST['plan']
            trip.save()
            return redirect("/dashboard")
        else:
            return redirect("/dashboard")
    else:
        return redirect("/")

def view_trip(request, trip_id):
    if 'userid' in request.session:
        trip = Trip.objects.get(id = trip_id)
        context = {
            'current_trip': trip,
            'creator': trip.creator,
            'joined': Trip.objects.get(id = trip_id).user.all()[1:10],
        }
        return render(request, 'login_reg/view_trip.html', context)
    else: 
        return redirect("/")

def delete(request, trip_id):
    if 'userid' in request.session:
        trip = Trip.objects.get(id = trip_id)
        user = Trip.objects.get(id = trip_id).user.first()
        if int(request.session['userid']) == user.id:
            trip.delete()
            return redirect("/dashboard")
        else: 
            return redirect("/dashboard")
    else: 
        return redirect("/")

def log_out(request):
    request.session.clear()
    return redirect("/")
