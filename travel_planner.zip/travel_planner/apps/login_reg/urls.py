from django.conf.urls import url
from . import views
                    
urlpatterns = [
    url(r'^log_out$', views.log_out),
    url(r'^leave_trip/(?P<trip_id>\d+)', views.leave_trip),
    url(r'^join_trip/(?P<trip_id>\d+)', views.join_trip),
    url(r'^delete/(?P<trip_id>\d+)', views.delete),
    url(r'^view_trip/(?P<trip_id>\d+)$', views.view_trip),
    url(r'^edit_trip/(?P<trip_id>\d+)$', views.edit_trip),
    url(r'change_trip', views.change_trip),
    url(r'^new_trip$', views.new_trip),
    url(r'^add_trip$', views.add_trip),
    url(r'^dashboard$', views.dashboard),
    url(r'^login$', views.login),
    url(r'^register$', views.register),
    url(r'^$', views.login_reg),
]
